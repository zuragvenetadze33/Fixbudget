const ids=["area","laborRate","materials","electric","plumbing","transport","other","reserve"];
const money = n => `${n.toFixed(2)} ₾`;
function val(id){const n=parseFloat(document.getElementById(id).value);return Number.isFinite(n)?Math.max(0,n):0;}
function calculate(){
  const labor=val("area")*val("laborRate");
  const base=labor+val("materials")+val("electric")+val("plumbing")+val("transport")+val("other");
  const reserve=base*val("reserve")/100;
  const total=base+reserve;
  document.getElementById("laborTotal").textContent=money(labor);
  document.getElementById("baseTotal").textContent=money(base);
  document.getElementById("reserveTotal").textContent=money(reserve);
  document.getElementById("total").textContent=total.toFixed(2);
}
function clearAll(){
  ids.forEach(id=>document.getElementById(id).value=id==="reserve"?"10":"");
  document.getElementById("laborTotal").textContent="0.00 ₾";
  document.getElementById("baseTotal").textContent="0.00 ₾";
  document.getElementById("reserveTotal").textContent="0.00 ₾";
  document.getElementById("total").textContent="0.00";
}
document.getElementById("calculate").addEventListener("click",calculate);
document.getElementById("clear").addEventListener("click",clearAll);
ids.forEach(id=>document.getElementById(id).addEventListener("input",calculate));
calculate();
